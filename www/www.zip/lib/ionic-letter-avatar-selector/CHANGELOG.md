### 1.0.3 (2016-05-08)

#### Changes

* **configuration provider:** Number of letters option renamed: `letters` to `letterNumber`
* **configuration provider:** New option added: `finishOnStateChange` (If `true`, selection is finished on angular state change, default is `false`)

### 1.0.2 (2016-02-29)

#### Changes

* **directives:** The `item` attribute of the `ion-item` directive is optional now. If it is not defined, only letter avatars will be visible without the item selection feature.

### 1.0.1 (2016-02-27)

#### Changes

* **directives:** shortened directive identifiers for finishing and deleting selection 

### 1.0.0 (2016-02-25)



